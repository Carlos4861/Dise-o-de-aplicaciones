const input = document.getElementById("item-input");
const submitBtn = document.getElementById("submit-btn");
const listContainer = document.getElementById("list-container");
const clearBtn = document.getElementById("clear-btn");

let items = [];

 function renderList() {
  listContainer.innerHTML = "";
  items.forEach((item, index) => {
    const div = document.createElement("div");
    div.classList.add("list-item");
    div.innerHTML = `
      <span>${item}</span>
      <button class="edit" onclick="editItem(${index})">✏️</button>
      <button class="delete" onclick="deleteItem(${index})">🗑️</button>
    `;
    listContainer.appendChild(div);
  });
}

 submitBtn.addEventListener("click", () => {
  const newItem = input.value.trim();
  if (newItem) {
    items.push(newItem);
    input.value = "";
    renderList();
  }
});

 function editItem(index) {
  const updatedItem = prompt("Edit item:", items[index]);
  if (updatedItem !== null && updatedItem.trim() !== "") {
    items[index] = updatedItem.trim();
    renderList();
  }
}

 function deleteItem(index) {
  items.splice(index, 1);
  renderList();
}

 clearBtn.addEventListener("click", () => {
  items = [];
  renderList();
});
